// Serveur de démarrage Yarra Market
// 1) Installer Node.js
// 2) Dans ce dossier: npm install
// 3) npm start
const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json());
app.use(express.static(path.join(__dirname, "../public")));
app.get("/api/health", (_,res)=>res.json({ok:true,service:"Yarra Market"}));
app.get("*", (_,res)=>res.sendFile(path.join(__dirname,"../public/index.html")));
app.listen(PORT, ()=>console.log(`Yarra Market: http://localhost:${PORT}`));
