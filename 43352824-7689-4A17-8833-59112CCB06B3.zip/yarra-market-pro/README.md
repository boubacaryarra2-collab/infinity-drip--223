# Yarra Market — version professionnelle de départ 🇲🇱

## Ce qui est inclus
- Interface marketplace responsive
- Accueil, catégories, recherche
- Catalogue de produits
- Panier avec sauvegarde locale
- Checkout de démonstration
- Formulaire vendeur
- Tableau de bord vendeur de démonstration
- API `/api/health`
- Serveur Node/Express prêt pour branchement d'une vraie base de données

## Lancer sur ordinateur
```bash
npm install
npm start
```
Puis ouvrir `http://localhost:3000`.

## Pour la mise en production
Il reste à connecter :
- une base de données (PostgreSQL/Supabase, par exemple)
- authentification réelle
- stockage des photos
- paiement Mobile Money / carte selon les prestataires disponibles au Mali
- système de livraison
- notifications SMS/WhatsApp
- vérification d'identité des vendeurs
- hébergement + nom de domaine
- pages légales (CGV, confidentialité, retours)

Ne mets jamais de clés secrètes directement dans `public/index.html`.
